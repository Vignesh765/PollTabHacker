# polltabhacker
Just a simple py script which increases votes in polltab.



Try to use proxy list and update the proxy list with new one once you receive lot of alreadyVoted status.

it was made only for educational purposes :-)

you can get proxy list.txt from sslproxies24.top 


Dont change proxy format - ip:port
eg- 12.12.12.12:3128
